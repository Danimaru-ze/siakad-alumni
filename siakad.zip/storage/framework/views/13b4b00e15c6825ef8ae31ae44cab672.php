<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        Buat Lowongan Kerja Baru
     <?php $__env->endSlot(); ?>

    <div class="p-6 sm:p-8 bg-white dark:bg-gray-800 shadow sm:rounded-lg">
        <div class="max-w-3xl mx-auto">
            <h2 class="text-lg font-medium text-gray-900 dark:text-gray-100">
                Detail Lowongan
            </h2>
            <p class="mt-1 text-sm text-gray-600 dark:text-gray-400">
                Isi detail lowongan kerja di bawah ini. Lowongan akan disimpan sebagai draft.
            </p>

            <form action="<?php echo e(route('hrd.jobs.store')); ?>" method="POST" class="mt-6 space-y-6">
                <?php echo csrf_field(); ?>
                
                <div class="grid grid-cols-1 gap-6 sm:grid-cols-2">
                    <div class="sm:col-span-2">
                        <label for="judul" class="block text-sm font-medium text-gray-700 dark:text-gray-300">Judul Pekerjaan</label>
                        <input type="text" name="judul" id="judul" value="<?php echo e(old('judul')); ?>" class="input-saas mt-1 block w-full" required>
                    </div>
                    
                    <div>
                        <label for="lokasi" class="block text-sm font-medium text-gray-700 dark:text-gray-300">Lokasi</label>
                        <input type="text" name="lokasi" id="lokasi" value="<?php echo e(old('lokasi')); ?>" placeholder="cth: Jakarta, Remote" class="input-saas mt-1 block w-full" required>
                    </div>

                    <div>
                        <label for="tipe_pekerjaan" class="block text-sm font-medium text-gray-700 dark:text-gray-300">Tipe Pekerjaan</label>
                        <input type="text" name="tipe_pekerjaan" id="tipe_pekerjaan" value="<?php echo e(old('tipe_pekerjaan')); ?>" placeholder="cth: Full-time, Internship" class="input-saas mt-1 block w-full" required>
                    </div>

                    <div>
                        <label for="kisaran_gaji_min" class="block text-sm font-medium text-gray-700 dark:text-gray-300">Gaji Minimum (Opsional)</label>
                        <input type="number" name="kisaran_gaji_min" id="kisaran_gaji_min" value="<?php echo e(old('kisaran_gaji_min')); ?>" class="input-saas mt-1 block w-full" placeholder="cth: 5000000">
                    </div>
                    
                    <div>
                        <label for="kisaran_gaji_max" class="block text-sm font-medium text-gray-700 dark:text-gray-300">Gaji Maksimum (Opsional)</label>
                        <input type="number" name="kisaran_gaji_max" id="kisaran_gaji_max" value="<?php echo e(old('kisaran_gaji_max')); ?>" class="input-saas mt-1 block w-full" placeholder="cth: 8000000">
                    </div>

                     <div class="sm:col-span-2">
                        <label for="deadline_lamaran" class="block text-sm font-medium text-gray-700 dark:text-gray-300">Deadline Lamaran (Opsional)</label>
                        <input type="date" name="deadline_lamaran" id="deadline_lamaran" value="<?php echo e(old('deadline_lamaran')); ?>" class="input-saas mt-1 block w-full">
                    </div>

                    <div class="sm:col-span-2">
                        <label for="deskripsi" class="block text-sm font-medium text-gray-700 dark:text-gray-300">Deskripsi</label>
                        <textarea name="deskripsi" id="deskripsi" rows="8" class="input-saas mt-1 block w-full" required><?php echo e(old('deskripsi')); ?></textarea>
                    </div>
                </div>

                <div class="flex justify-end gap-4">
                    <a href="<?php echo e(route('hrd.jobs.index')); ?>" class="btn-ghost-saas px-6 py-2 rounded-lg">
                        Batal
                    </a>
                    <button type="submit" class="btn-primary-saas px-6 py-2 rounded-lg">
                        Simpan Draft
                    </button>
                </div>
            </form>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH D:\PROJECT-CODING\Project-Kuliah\siakad\resources\views/hrd/jobs/create.blade.php ENDPATH**/ ?>