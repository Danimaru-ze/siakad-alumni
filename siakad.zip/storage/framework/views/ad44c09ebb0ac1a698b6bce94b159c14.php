<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        Lowongan Saya
     <?php $__env->endSlot(); ?>

    <div x-data="{ deleteModal: false, submitModal: false, selectedJob: null }">
        <div class="p-6 sm:p-8 bg-white dark:bg-gray-800 shadow sm:rounded-lg">
            <div class="max-w-full">
                <div class="flex justify-between items-center">
                    <div>
                        <h2 class="text-lg font-medium text-gray-900 dark:text-gray-100">
                            Kelola Lowongan Kerja Anda
                        </h2>
                        <p class="mt-1 text-sm text-gray-600 dark:text-gray-400">
                            Buat, edit, dan ajukan lowongan kerja dari perusahaan Anda.
                        </p>
                    </div>
                    <a href="<?php echo e(route('hrd.jobs.create')); ?>" class="btn-primary-saas px-4 py-2 rounded-lg">
                        Buat Lowongan Baru
                    </a>
                </div>

                <div class="mt-6 overflow-x-auto">
                    <table class="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                        <thead class="bg-gray-50 dark:bg-gray-700">
                            <tr>
                                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Judul</th>
                                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Status</th>
                                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Dibuat</th>
                                <th scope="col" class="px-6 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Aksi</th>
                            </tr>
                        </thead>
                        <tbody class="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
                            <?php $__empty_1 = true; $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <div class="text-sm font-medium text-gray-900 dark:text-gray-100"><?php echo e($job->judul); ?></div>
                                        <div class="text-sm text-gray-500 dark:text-gray-400"><?php echo e($job->lokasi); ?></div>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <?php if (isset($component)) { $__componentOriginal4cad57415998541528befff6353295c4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4cad57415998541528befff6353295c4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.job-status-badge','data' => ['status' => $job->status]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('job-status-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($job->status)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4cad57415998541528befff6353295c4)): ?>
<?php $attributes = $__attributesOriginal4cad57415998541528befff6353295c4; ?>
<?php unset($__attributesOriginal4cad57415998541528befff6353295c4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4cad57415998541528befff6353295c4)): ?>
<?php $component = $__componentOriginal4cad57415998541528befff6353295c4; ?>
<?php unset($__componentOriginal4cad57415998541528befff6353295c4); ?>
<?php endif; ?>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                                        <?php echo e($job->created_at->format('d M Y')); ?>

                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                                        <div class="flex items-center justify-end gap-3">
                                            <?php if(in_array($job->status, ['DRAFT', 'REJECTED'])): ?>
                                                <button @click="selectedJob = <?php echo e($job); ?>; submitModal = true" class="font-medium text-indigo-600 dark:text-indigo-400 hover:text-indigo-900">Ajukan</button>
                                                <a href="<?php echo e(route('hrd.jobs.edit', $job)); ?>" class="font-medium text-amber-600 dark:text-amber-400 hover:text-amber-900">Edit</a>
                                            <?php endif; ?>
                                            <button @click="selectedJob = <?php echo e($job); ?>; deleteModal = true" class="font-medium text-red-600 dark:text-red-400 hover:text-red-900">Hapus</button>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="4" class="px-6 py-4 whitespace-nowrap text-center text-sm text-gray-500 dark:text-gray-400">
                                        Anda belum membuat lowongan kerja.
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                <div class="mt-4">
                    <?php echo e($jobs->links()); ?>

                </div>
            </div>
        </div>

        <!-- Delete Modal -->
        <div x-cloak x-show="deleteModal" @keydown.escape.window="deleteModal = false" class="fixed inset-0 z-50 overflow-y-auto">
            <div class="flex items-center justify-center min-h-screen">
                <div @click="deleteModal = false" class="fixed inset-0 bg-gray-500/75"></div>
                <div @click.away="deleteModal = false" class="bg-white dark:bg-gray-800 rounded-lg shadow-xl w-full max-w-md p-6 z-10">
                    <form :action="'/hrd/jobs/' + selectedJob.id" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <h3 class="text-lg font-medium text-gray-900 dark:text-gray-100">Hapus Lowongan</h3>
                        <p class="mt-2 text-sm text-gray-500 dark:text-gray-400">Anda yakin ingin menghapus lowongan <strong x-text="selectedJob.judul"></strong>? Tindakan ini permanen.</p>
                        <div class="mt-6 flex justify-end gap-3">
                            <button type="button" @click="deleteModal = false" class="btn-ghost-saas px-4 py-2 rounded-lg">Batal</button>
                            <button type="submit" class="btn-primary-saas bg-red-600 hover:bg-red-700 px-4 py-2 rounded-lg">Hapus</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        
        <!-- Submit Modal -->
        <div x-cloak x-show="submitModal" @keydown.escape.window="submitModal = false" class="fixed inset-0 z-50 overflow-y-auto">
            <div class="flex items-center justify-center min-h-screen">
                <div @click="submitModal = false" class="fixed inset-0 bg-gray-500/75"></div>
                <div @click.away="submitModal = false" class="bg-white dark:bg-gray-800 rounded-lg shadow-xl w-full max-w-md p-6 z-10">
                    <form :action="'/hrd/jobs/' + selectedJob.id + '/submit'" method="POST">
                        <?php echo csrf_field(); ?>
                        <h3 class="text-lg font-medium text-gray-900 dark:text-gray-100">Ajukan Lowongan</h3>
                        <p class="mt-2 text-sm text-gray-500 dark:text-gray-400">Anda yakin ingin mengajukan lowongan <strong x-text="selectedJob.judul"></strong> untuk direview oleh admin?</p>
                        <div class="mt-6 flex justify-end gap-3">
                            <button type="button" @click="submitModal = false" class="btn-ghost-saas px-4 py-2 rounded-lg">Batal</button>
                            <button type="submit" class="btn-primary-saas px-4 py-2 rounded-lg">Ya, Ajukan</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH D:\PROJECT-CODING\Project-Kuliah\siakad\resources\views/hrd/jobs/index.blade.php ENDPATH**/ ?>