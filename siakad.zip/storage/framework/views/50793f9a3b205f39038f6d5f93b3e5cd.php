<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        Daftar Lowongan Kerja
     <?php $__env->endSlot(); ?>

    <div class="p-6 sm:p-8 bg-white dark:bg-gray-800 shadow sm:rounded-lg">
        <div class="max-w-full">
            <h2 class="text-lg font-medium text-gray-900 dark:text-gray-100">
                Temukan Peluang Karir Anda
            </h2>
            <p class="mt-1 text-sm text-gray-600 dark:text-gray-400">
                Jelajahi lowongan kerja yang tersedia dari mitra perusahaan kami.
            </p>

            <div class="mt-6 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <?php $__empty_1 = true; $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="card-saas p-6 flex flex-col">
                        <div class="flex-grow">
                            <h3 class="text-base font-semibold text-gray-900 dark:text-gray-100"><?php echo e($job->judul); ?></h3>
                            <p class="mt-1 text-sm font-medium text-indigo-600 dark:text-indigo-400"><?php echo e($job->company->nama_perusahaan); ?></p>
                            <p class="mt-2 text-sm text-gray-500 dark:text-gray-400">
                                <span class="font-medium">Lokasi:</span> <?php echo e($job->lokasi); ?> <br>
                                <span class="font-medium">Tipe:</span> <?php echo e($job->tipe_pekerjaan); ?>

                            </p>
                            <p class="mt-3 text-sm text-gray-600 dark:text-gray-400 line-clamp-3">
                                <?php echo e($job->deskripsi); ?>

                            </p>
                        </div>
                        <div class="mt-4 pt-4 border-t border-gray-200 dark:border-gray-700">
                            <p class="text-xs text-gray-500 dark:text-gray-400">
                                Kontak HRD: <span class="font-medium"><?php echo e($job->hrd->email); ?></span>
                            </p>
                            <a href="mailto:<?php echo e($job->hrd->email); ?>?subject=Lamaran%20Pekerjaan:%20<?php echo e(urlencode($job->judul)); ?>" class="mt-2 block w-full text-center btn-primary-saas px-4 py-2 rounded-lg text-sm">
                                Lamar Sekarang
                            </a>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="md:col-span-2 lg:col-span-3 text-center py-12">
                         <p class="text-gray-500 dark:text-gray-400">Saat ini tidak ada lowongan kerja yang tersedia.</p>
                    </div>
                <?php endif; ?>
            </div>

            <div class="mt-6">
                <?php echo e($jobs->links()); ?>

            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH D:\PROJECT-CODING\Project-Kuliah\siakad\resources\views/alumni/jobs/index.blade.php ENDPATH**/ ?>