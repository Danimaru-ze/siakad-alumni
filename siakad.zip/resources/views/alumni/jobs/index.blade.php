<x-app-layout>
    <x-slot name="header">
        Daftar Lowongan Kerja
    </x-slot>

    <div class="p-6 sm:p-8 bg-white dark:bg-gray-800 shadow sm:rounded-lg">
        <div class="max-w-full">
            <h2 class="text-lg font-medium text-gray-900 dark:text-gray-100">
                Temukan Peluang Karir Anda
            </h2>
            <p class="mt-1 text-sm text-gray-600 dark:text-gray-400">
                Jelajahi lowongan kerja yang tersedia dari mitra perusahaan kami.
            </p>

            <div class="mt-6 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                @forelse ($jobs as $job)
                    <div class="card-saas p-6 flex flex-col">
                        <div class="flex-grow">
                            <h3 class="text-base font-semibold text-gray-900 dark:text-gray-100">{{ $job->judul }}</h3>
                            <p class="mt-1 text-sm font-medium text-indigo-600 dark:text-indigo-400">{{ $job->company->nama_perusahaan }}</p>
                            <p class="mt-2 text-sm text-gray-500 dark:text-gray-400">
                                <span class="font-medium">Lokasi:</span> {{ $job->lokasi }} <br>
                                <span class="font-medium">Tipe:</span> {{ $job->tipe_pekerjaan }}
                            </p>
                            <p class="mt-3 text-sm text-gray-600 dark:text-gray-400 line-clamp-3">
                                {{ $job->deskripsi }}
                            </p>
                        </div>
                        <div class="mt-4 pt-4 border-t border-gray-200 dark:border-gray-700">
                            <p class="text-xs text-gray-500 dark:text-gray-400">
                                Kontak HRD: <span class="font-medium">{{ $job->hrd->email }}</span>
                            </p>
                            <a href="mailto:{{ $job->hrd->email }}?subject=Lamaran%20Pekerjaan:%20{{ urlencode($job->judul) }}" class="mt-2 block w-full text-center btn-primary-saas px-4 py-2 rounded-lg text-sm">
                                Lamar Sekarang
                            </a>
                        </div>
                    </div>
                @empty
                    <div class="md:col-span-2 lg:col-span-3 text-center py-12">
                         <p class="text-gray-500 dark:text-gray-400">Saat ini tidak ada lowongan kerja yang tersedia.</p>
                    </div>
                @endforelse
            </div>

            <div class="mt-6">
                {{ $jobs->links() }}
            </div>
        </div>
    </div>
</x-app-layout>
