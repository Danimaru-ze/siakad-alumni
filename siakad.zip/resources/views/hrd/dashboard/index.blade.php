<x-app-layout>
    <x-slot name="header">
        Dashboard HRD
    </x-slot>

    <div class="p-6 sm:p-8 bg-white dark:bg-gray-800 shadow sm:rounded-lg">
        <h2 class="text-lg font-medium text-gray-900 dark:text-gray-100">
            Selamat Datang, {{ Auth::user()->name }}!
        </h2>
        <p class="mt-1 text-sm text-gray-600 dark:text-gray-400">
            Gunakan menu di samping untuk mengelola lowongan kerja perusahaan Anda.
        </p>
    </div>
</x-app-layout>
