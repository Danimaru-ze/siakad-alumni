<x-app-layout>
    <x-slot name="header">
        Edit Lowongan Kerja
    </x-slot>

    <div class="p-6 sm:p-8 bg-white dark:bg-gray-800 shadow sm:rounded-lg">
        <div class="max-w-3xl mx-auto">
            <h2 class="text-lg font-medium text-gray-900 dark:text-gray-100">
                Detail Lowongan
            </h2>
            <p class="mt-1 text-sm text-gray-600 dark:text-gray-400">
                Perbarui detail lowongan kerja di bawah ini.
            </p>

            <form action="{{ route('hrd.jobs.update', $job) }}" method="POST" class="mt-6 space-y-6">
                @csrf
                @method('PUT')
                
                <div class="grid grid-cols-1 gap-6 sm:grid-cols-2">
                    <div class="sm:col-span-2">
                        <label for="judul" class="block text-sm font-medium text-gray-700 dark:text-gray-300">Judul Pekerjaan</label>
                        <input type="text" name="judul" id="judul" value="{{ old('judul', $job->judul) }}" class="input-saas mt-1 block w-full" required>
                    </div>
                    
                    <div>
                        <label for="lokasi" class="block text-sm font-medium text-gray-700 dark:text-gray-300">Lokasi</label>
                        <input type="text" name="lokasi" id="lokasi" value="{{ old('lokasi', $job->lokasi) }}" placeholder="cth: Jakarta, Remote" class="input-saas mt-1 block w-full" required>
                    </div>

                    <div>
                        <label for="tipe_pekerjaan" class="block text-sm font-medium text-gray-700 dark:text-gray-300">Tipe Pekerjaan</label>
                        <input type="text" name="tipe_pekerjaan" id="tipe_pekerjaan" value="{{ old('tipe_pekerjaan', $job->tipe_pekerjaan) }}" placeholder="cth: Full-time, Internship" class="input-saas mt-1 block w-full" required>
                    </div>

                    <div>
                        <label for="kisaran_gaji_min" class="block text-sm font-medium text-gray-700 dark:text-gray-300">Gaji Minimum (Opsional)</label>
                        <input type="number" name="kisaran_gaji_min" id="kisaran_gaji_min" value="{{ old('kisaran_gaji_min', $job->kisaran_gaji_min) }}" class="input-saas mt-1 block w-full" placeholder="cth: 5000000">
                    </div>
                    
                    <div>
                        <label for="kisaran_gaji_max" class="block text-sm font-medium text-gray-700 dark:text-gray-300">Gaji Maksimum (Opsional)</label>
                        <input type="number" name="kisaran_gaji_max" id="kisaran_gaji_max" value="{{ old('kisaran_gaji_max', $job->kisaran_gaji_max) }}" class="input-saas mt-1 block w-full" placeholder="cth: 8000000">
                    </div>

                     <div class="sm:col-span-2">
                        <label for="deadline_lamaran" class="block text-sm font-medium text-gray-700 dark:text-gray-300">Deadline Lamaran (Opsional)</label>
                        <input type="date" name="deadline_lamaran" id="deadline_lamaran" value="{{ old('deadline_lamaran', $job->deadline_lamaran ? \Carbon\Carbon::parse($job->deadline_lamaran)->format('Y-m-d') : '') }}" class="input-saas mt-1 block w-full">
                    </div>

                    <div class="sm:col-span-2">
                        <label for="deskripsi" class="block text-sm font-medium text-gray-700 dark:text-gray-300">Deskripsi</label>
                        <textarea name="deskripsi" id="deskripsi" rows="8" class="input-saas mt-1 block w-full" required>{{ old('deskripsi', $job->deskripsi) }}</textarea>
                    </div>
                </div>

                <div class="flex justify-end gap-4">
                    <a href="{{ route('hrd.jobs.index') }}" class="btn-ghost-saas px-6 py-2 rounded-lg">
                        Batal
                    </a>
                    <button type="submit" class="btn-primary-saas px-6 py-2 rounded-lg">
                        Simpan Perubahan
                    </button>
                </div>
            </form>
        </div>
    </div>
</x-app-layout>
