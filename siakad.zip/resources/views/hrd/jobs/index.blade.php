<x-app-layout>
    <x-slot name="header">
        Lowongan Saya
    </x-slot>

    <div x-data="{ deleteModal: false, submitModal: false, selectedJob: null }">
        <div class="p-6 sm:p-8 bg-white dark:bg-gray-800 shadow sm:rounded-lg">
            <div class="max-w-full">
                <div class="flex justify-between items-center">
                    <div>
                        <h2 class="text-lg font-medium text-gray-900 dark:text-gray-100">
                            Kelola Lowongan Kerja Anda
                        </h2>
                        <p class="mt-1 text-sm text-gray-600 dark:text-gray-400">
                            Buat, edit, dan ajukan lowongan kerja dari perusahaan Anda.
                        </p>
                    </div>
                    <a href="{{ route('hrd.jobs.create') }}" class="btn-primary-saas px-4 py-2 rounded-lg">
                        Buat Lowongan Baru
                    </a>
                </div>

                <div class="mt-6 overflow-x-auto">
                    <table class="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                        <thead class="bg-gray-50 dark:bg-gray-700">
                            <tr>
                                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Judul</th>
                                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Status</th>
                                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Dibuat</th>
                                <th scope="col" class="px-6 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Aksi</th>
                            </tr>
                        </thead>
                        <tbody class="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
                            @forelse ($jobs as $job)
                                <tr>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <div class="text-sm font-medium text-gray-900 dark:text-gray-100">{{ $job->judul }}</div>
                                        <div class="text-sm text-gray-500 dark:text-gray-400">{{ $job->lokasi }}</div>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <x-job-status-badge :status="$job->status" />
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                                        {{ $job->created_at->format('d M Y') }}
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                                        <div class="flex items-center justify-end gap-3">
                                            @if(in_array($job->status, ['DRAFT', 'REJECTED']))
                                                <button @click="selectedJob = {{ $job }}; submitModal = true" class="font-medium text-indigo-600 dark:text-indigo-400 hover:text-indigo-900">Ajukan</button>
                                                <a href="{{ route('hrd.jobs.edit', $job) }}" class="font-medium text-amber-600 dark:text-amber-400 hover:text-amber-900">Edit</a>
                                            @endif
                                            <button @click="selectedJob = {{ $job }}; deleteModal = true" class="font-medium text-red-600 dark:text-red-400 hover:text-red-900">Hapus</button>
                                        </div>
                                    </td>
                                </tr>
                            @empty
                                <tr>
                                    <td colspan="4" class="px-6 py-4 whitespace-nowrap text-center text-sm text-gray-500 dark:text-gray-400">
                                        Anda belum membuat lowongan kerja.
                                    </td>
                                </tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>
                <div class="mt-4">
                    {{ $jobs->links() }}
                </div>
            </div>
        </div>

        <!-- Delete Modal -->
        <div x-cloak x-show="deleteModal" @keydown.escape.window="deleteModal = false" class="fixed inset-0 z-50 overflow-y-auto">
            <div class="flex items-center justify-center min-h-screen">
                <div @click="deleteModal = false" class="fixed inset-0 bg-gray-500/75"></div>
                <div @click.away="deleteModal = false" class="bg-white dark:bg-gray-800 rounded-lg shadow-xl w-full max-w-md p-6 z-10">
                    <form :action="'/hrd/jobs/' + selectedJob.id" method="POST">
                        @csrf
                        @method('DELETE')
                        <h3 class="text-lg font-medium text-gray-900 dark:text-gray-100">Hapus Lowongan</h3>
                        <p class="mt-2 text-sm text-gray-500 dark:text-gray-400">Anda yakin ingin menghapus lowongan <strong x-text="selectedJob.judul"></strong>? Tindakan ini permanen.</p>
                        <div class="mt-6 flex justify-end gap-3">
                            <button type="button" @click="deleteModal = false" class="btn-ghost-saas px-4 py-2 rounded-lg">Batal</button>
                            <button type="submit" class="btn-primary-saas bg-red-600 hover:bg-red-700 px-4 py-2 rounded-lg">Hapus</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        
        <!-- Submit Modal -->
        <div x-cloak x-show="submitModal" @keydown.escape.window="submitModal = false" class="fixed inset-0 z-50 overflow-y-auto">
            <div class="flex items-center justify-center min-h-screen">
                <div @click="submitModal = false" class="fixed inset-0 bg-gray-500/75"></div>
                <div @click.away="submitModal = false" class="bg-white dark:bg-gray-800 rounded-lg shadow-xl w-full max-w-md p-6 z-10">
                    <form :action="'/hrd/jobs/' + selectedJob.id + '/submit'" method="POST">
                        @csrf
                        <h3 class="text-lg font-medium text-gray-900 dark:text-gray-100">Ajukan Lowongan</h3>
                        <p class="mt-2 text-sm text-gray-500 dark:text-gray-400">Anda yakin ingin mengajukan lowongan <strong x-text="selectedJob.judul"></strong> untuk direview oleh admin?</p>
                        <div class="mt-6 flex justify-end gap-3">
                            <button type="button" @click="submitModal = false" class="btn-ghost-saas px-4 py-2 rounded-lg">Batal</button>
                            <button type="submit" class="btn-primary-saas px-4 py-2 rounded-lg">Ya, Ajukan</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</x-app-layout>
