@props(['context' => 'admin'])

<x-app-layout>
    <x-slot name="header">
        Daftar Alumni
    </x-slot>

    <div class="p-6 sm:p-8 bg-white dark:bg-gray-800 shadow sm:rounded-lg">
        <div class="max-w-full">
            <div class="flex justify-between items-center">
                <div>
                    <h2 class="text-lg font-medium text-gray-900 dark:text-gray-100">
                        @if($context === 'hrd')
                            Database Alumni untuk Rekrutmen
                        @else
                            Database Alumni
                        @endif
                    </h2>
                    <p class="mt-1 text-sm text-gray-600 dark:text-gray-400">
                        Lihat dan filter daftar alumni untuk keperluan rekrutmen.
                    </p>
                </div>
            </div>

            <!-- Filters -->
            <form method="GET" action="{{ url()->current() }}" class="mt-6">
                <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
                    <div>
                        <label for="prodi_id" class="block text-sm font-medium text-gray-700 dark:text-gray-300">Program Studi</label>
                        <select name="prodi_id" id="prodi_id" class="input-saas mt-1 block w-full">
                            <option value="">Semua Prodi</option>
                            @foreach($prodis as $prodi)
                                <option value="{{ $prodi->id }}" @selected(request('prodi_id') == $prodi->id)>{{ $prodi->nama }}</option>
                            @endforeach
                        </select>
                    </div>
                    <div>
                        <label for="tahun_lulus" class="block text-sm font-medium text-gray-700 dark:text-gray-300">Tahun Lulus</label>
                        <input type="number" name="tahun_lulus" id="tahun_lulus" value="{{ request('tahun_lulus') }}" class="input-saas mt-1 block w-full" placeholder="cth: 2024">
                    </div>
                    <div class="flex items-end">
                        <button type="submit" class="btn-primary-saas px-4 py-2 rounded-lg">Filter</button>
                         <a href="{{ url()->current() }}" class="ml-2 btn-ghost-saas px-4 py-2 rounded-lg">Reset</a>
                    </div>
                </div>
            </form>

            <div class="mt-6 overflow-x-auto">
                <table class="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                    <thead class="bg-gray-50 dark:bg-gray-700">
                        <tr>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Nama Alumni</th>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">NIM</th>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Program Studi</th>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Tahun Lulus</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
                        @forelse ($alumni as $alumnus)
                            <tr>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <div class="text-sm font-medium text-gray-900 dark:text-gray-100">{{ $alumnus->user->name }}</div>
                                    <div class="text-sm text-gray-500 dark:text-gray-400">{{ $alumnus->user->email }}</div>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                                    {{ $alumnus->nim }}
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                                    {{ $alumnus->prodi->nama }}
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                                     {{-- Assuming graduation year is when the status was updated --}}
                                    {{ $alumnus->updated_at->format('Y') }}
                                </td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="4" class="px-6 py-4 whitespace-nowrap text-center text-sm text-gray-500 dark:text-gray-400">
                                    Tidak ada data alumni yang cocok.
                                </td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
            <div class="mt-4">
                {{ $alumni->appends(request()->query())->links() }}
            </div>
        </div>
    </div>
</x-app-layout>
