<?php

namespace App\Http\Controllers\HRD;

use App\Http\Controllers\Controller;
use App\Models\Company;
use App\Models\HrdProfile;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class ProfileController extends Controller
{
    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('hrd.profile.setup');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $request->validate([
            'nama_hrd' => 'required|string|max:255',
            'jabatan_hrd' => 'required|string|max:255',
            'nama_perusahaan' => 'required|string|max:255',
            'email_perusahaan' => 'required|email|max:255|unique:companies,email',
            'website' => 'nullable|url|max:255',
            'alamat' => 'required|string|max:1000',
        ]);

        $user = Auth::user();

        try {
            DB::transaction(function () use ($request, $user) {
                // Create company
                $company = Company::create([
                    'nama_perusahaan' => $request->input('nama_perusahaan'),
                    'email' => $request->input('email_perusahaan'),
                    'website' => $request->input('website'),
                    'alamat' => $request->input('alamat'),
                ]);

                // Create HRD Profile
                HrdProfile::create([
                    'user_id' => $user->id,
                    'company_id' => $company->id,
                    'nama_hrd' => $request->input('nama_hrd'),
                    'jabatan_hrd' => $request->input('jabatan_hrd'),
                    'email_hrd' => $user->email, // Use user's email for HRD email
                ]);
            });
        } catch (\Exception $e) {
            return back()->with('error', 'Gagal menyimpan profil. Silakan coba lagi.')->withInput();
        }

        return redirect()->route('hrd.dashboard')->with('success', 'Profil berhasil disimpan.');
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit()
    {
        $user = Auth::user();
        $hrdProfile = $user->hrdProfile()->with('company')->firstOrFail();

        return view('hrd.profile.edit', compact('hrdProfile'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request)
    {
        $user = Auth::user();
        $hrdProfile = $user->hrdProfile()->firstOrFail();
        $company = $hrdProfile->company;

        $request->validate([
            'nama_hrd' => 'required|string|max:255',
            'jabatan_hrd' => 'required|string|max:255',
            'nama_perusahaan' => 'required|string|max:255',
            'email_perusahaan' => 'required|email|max:255|unique:companies,email,' . $company->id,
            'website' => 'nullable|url|max:255',
            'alamat' => 'required|string|max:1000',
            'telepon_perusahaan' => 'nullable|string|max:20',
        ]);

        try {
            DB::transaction(function () use ($request, $hrdProfile, $company) {
                $hrdProfile->update([
                    'nama_hrd' => $request->input('nama_hrd'),
                    'jabatan_hrd' => $request->input('jabatan_hrd'),
                ]);

                $company->update([
                    'nama_perusahaan' => $request->input('nama_perusahaan'),
                    'email' => $request->input('email_perusahaan'),
                    'website' => $request->input('website'),
                    'alamat' => $request->input('alamat'),
                    'telepon' => $request->input('telepon_perusahaan'),
                ]);
            });
        } catch (\Exception $e) {
            return back()->with('error', 'Gagal memperbarui profil. Silakan coba lagi.')->withInput();
        }

        return redirect()->route('hrd.profile.edit')->with('success', 'Profil berhasil diperbarui.');
    }
}