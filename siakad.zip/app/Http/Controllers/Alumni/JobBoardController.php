<?php

namespace App\Http\Controllers\Alumni;

use App\Http\Controllers\Controller;
use App\Models\JobVacancy;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class JobBoardController extends Controller
{
    public function index()
    {
        $user = Auth::user();
        // Assuming alumni role will be set up
        if ($user->role !== 'alumni') {
            abort(403);
        }

        $jobs = JobVacancy::forUser($user)->with(['company', 'hrd'])->latest()->paginate(9);

        return view('alumni.jobs.index', compact('jobs'));
    }
}
